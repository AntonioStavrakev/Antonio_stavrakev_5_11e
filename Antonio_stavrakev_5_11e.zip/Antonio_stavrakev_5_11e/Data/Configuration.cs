﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Antonio_stavrakev_5_11e.Data
{
	public class Configuration
	{
		public const string connectionString = "Server=(localdb)\\mssqllocaldb;Database=LibraryDB;Integrated Security=true; Encrypt=Yes;Trusted_Connection=True;";
	}
}
